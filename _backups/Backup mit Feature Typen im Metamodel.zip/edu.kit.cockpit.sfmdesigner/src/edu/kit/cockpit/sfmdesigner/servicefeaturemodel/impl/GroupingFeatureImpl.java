/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package edu.kit.cockpit.sfmdesigner.servicefeaturemodel.impl;

import edu.kit.cockpit.sfmdesigner.servicefeaturemodel.AbstractFeature;
import edu.kit.cockpit.sfmdesigner.servicefeaturemodel.GroupingFeature;
import edu.kit.cockpit.sfmdesigner.servicefeaturemodel.ServicefeaturemodelPackage;

import java.util.Collection;
import java.util.List;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Grouping Feature</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link edu.kit.cockpit.sfmdesigner.servicefeaturemodel.impl.GroupingFeatureImpl#getChildGroupingFeatures <em>Child Grouping Features</em>}</li>
 *   <li>{@link edu.kit.cockpit.sfmdesigner.servicefeaturemodel.impl.GroupingFeatureImpl#getChildAbstractFeatures <em>Child Abstract Features</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class GroupingFeatureImpl extends ServiceFeatureImpl implements GroupingFeature {
	/**
	 * The cached value of the '{@link #getChildGroupingFeatures() <em>Child Grouping Features</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildGroupingFeatures()
	 * @generated
	 * @ordered
	 */
	protected EList<GroupingFeature> childGroupingFeatures;

	/**
	 * The cached value of the '{@link #getChildAbstractFeatures() <em>Child Abstract Features</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getChildAbstractFeatures()
	 * @generated
	 * @ordered
	 */
	protected EList<AbstractFeature> childAbstractFeatures;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected GroupingFeatureImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ServicefeaturemodelPackage.Literals.GROUPING_FEATURE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List<GroupingFeature> getChildGroupingFeatures() {
		if (childGroupingFeatures == null) {
			childGroupingFeatures = new EObjectContainmentEList<GroupingFeature>(GroupingFeature.class, this, ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES);
		}
		return childGroupingFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public List<AbstractFeature> getChildAbstractFeatures() {
		if (childAbstractFeatures == null) {
			childAbstractFeatures = new EObjectContainmentEList<AbstractFeature>(AbstractFeature.class, this, ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES);
		}
		return childAbstractFeatures;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES:
				return ((InternalEList<?>)getChildGroupingFeatures()).basicRemove(otherEnd, msgs);
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES:
				return ((InternalEList<?>)getChildAbstractFeatures()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES:
				return getChildGroupingFeatures();
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES:
				return getChildAbstractFeatures();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES:
				getChildGroupingFeatures().clear();
				getChildGroupingFeatures().addAll((Collection<? extends GroupingFeature>)newValue);
				return;
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES:
				getChildAbstractFeatures().clear();
				getChildAbstractFeatures().addAll((Collection<? extends AbstractFeature>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES:
				getChildGroupingFeatures().clear();
				return;
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES:
				getChildAbstractFeatures().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_GROUPING_FEATURES:
				return childGroupingFeatures != null && !childGroupingFeatures.isEmpty();
			case ServicefeaturemodelPackage.GROUPING_FEATURE__CHILD_ABSTRACT_FEATURES:
				return childAbstractFeatures != null && !childAbstractFeatures.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //GroupingFeatureImpl
