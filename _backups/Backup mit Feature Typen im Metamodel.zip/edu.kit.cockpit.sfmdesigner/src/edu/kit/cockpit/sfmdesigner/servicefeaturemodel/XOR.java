/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package edu.kit.cockpit.sfmdesigner.servicefeaturemodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>XOR</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.kit.cockpit.sfmdesigner.servicefeaturemodel.ServicefeaturemodelPackage#getXOR()
 * @model
 * @generated
 */
public interface XOR extends Variant {
} // XOR
