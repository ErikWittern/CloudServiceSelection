/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package edu.kit.cockpit.sfmdesigner.servicefeaturemodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Optional Service Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.kit.cockpit.sfmdesigner.servicefeaturemodel.ServicefeaturemodelPackage#getOptionalServiceFeature()
 * @model
 * @generated
 */
public interface OptionalServiceFeature extends ServiceFeature {
} // OptionalServiceFeature
