/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package edu.kit.cockpit.sfmdesigner.servicefeaturemodel;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Mandatory Service Feature</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see edu.kit.cockpit.sfmdesigner.servicefeaturemodel.ServicefeaturemodelPackage#getMandatoryServiceFeature()
 * @model
 * @generated
 */
public interface MandatoryServiceFeature extends ServiceFeature {
} // MandatoryServiceFeature
