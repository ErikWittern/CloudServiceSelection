package edu.kit.cockpit.sfmdesigner.analyzer.domain.java;

public enum ScaleOrder {
	HIGHERISBETTER,
	LOWERISBETTER,
	EXISTENCEISBETTER;
}
