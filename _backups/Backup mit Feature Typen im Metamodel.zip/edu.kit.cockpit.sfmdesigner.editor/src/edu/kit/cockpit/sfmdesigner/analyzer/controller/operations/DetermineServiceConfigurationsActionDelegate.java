package edu.kit.cockpit.sfmdesigner.analyzer.controller.operations;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

import edu.kit.cockpit.sfmdesigner.analyzer.controller.core.CPHandler;
import edu.kit.cockpit.sfmdesigner.servicefeaturemodel.Service;

import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.edit.ui.util.EditUIUtil;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.dialogs.ProgressMonitorDialog;
import org.eclipse.jface.operation.IRunnableWithProgress;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.PlatformUI;
import org.eclipse.ui.actions.ActionDelegate;

public class DetermineServiceConfigurationsActionDelegate extends ActionDelegate implements IActionDelegate {

	CPHandler cpHandler;
		
	public void run(IAction action) {
		System.out.println("DetermineServiceConfigurationsActionDelegate in Java");
		try {
			new ProgressMonitorDialog(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getShell()).run(false, false, new IRunnableWithProgress() {
				public void run(IProgressMonitor monitor) throws InvocationTargetException, InterruptedException {
					monitor.setTaskName("Determining service configurations.");

					cpHandler = new CPHandler();
					
					ResourceSet resourceSet = new ResourceSetImpl();
					URI resourceURI = EditUIUtil.getURI(PlatformUI.getWorkbench().getActiveWorkbenchWindow().getActivePage().getActiveEditor().getEditorInput());
					Resource resource = resourceSet.getResource(resourceURI, true);
					Service serviceModel = (Service)resource.getContents().get(0);
					cpHandler.getAllConfigurations(serviceModel, false);
					try {
						resource.save(null);
					} catch (IOException e) {
						e.printStackTrace();
					}

				}
			});
		} catch (InvocationTargetException e2) {
			e2.printStackTrace();
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}
	}
}