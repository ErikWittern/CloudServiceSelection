/*
 * Project: Cockpit Service Feature Model designer
 * Author:  Erik Wittern
 * Copyright (c): KIT, 2011
 */

package edu.kit.cockpit.sfmdesigner.servicefeaturemodel.presentation;

public class View {

}
