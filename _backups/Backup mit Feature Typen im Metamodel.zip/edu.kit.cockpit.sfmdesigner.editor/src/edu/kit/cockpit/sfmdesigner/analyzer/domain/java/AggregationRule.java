package edu.kit.cockpit.sfmdesigner.analyzer.domain.java;

public enum AggregationRule {

	SUM,
	PRODUCT,
	ATLEASTONCE;
}
